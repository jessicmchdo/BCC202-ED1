#ifndef r9_h
#define r9_h

int soma_r9(int n);

#endif