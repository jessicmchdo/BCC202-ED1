//usar passagem por referencia
void lerOrdem(int *ordem);
//usar passagem por referencia
void lerOperacao(char *operacao);
//manter como especificado
double **alocaMatriz(int ordem);
//manter como especificado
void desalocaMatriz(double ***M, int ordem);
//manter como especificado
void lerMatriz(double **M, int ordem);
//manter como especificado
double somaMatriz(double **M, int ordem);
//manter como especificado
double media(double resultado, int ordem);
//manter como especificado
void printResultado(double resultado);
